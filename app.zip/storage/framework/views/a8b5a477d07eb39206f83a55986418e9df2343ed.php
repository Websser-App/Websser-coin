<style>
        input[type=file]{
            width:90px;
            color:transparent;
            display: block;
        }
        input[type=file] button{
            
            color:#5256ad;
            display: block;
        }
        .pugaso{
            border: 5px dashed #ddd;
        }
        .drag-area{
            
            border: 5px dashed #ddd;
            
            border-radius: 5px;
            text-align: center;
            
        }
        .tg{
            margin-top:20%;
            margin-bottom: 20%;
        }
        .drag-area.active{
            background-color: #b8d4fe;
            color: black;
            border: 2px dashed #618ac9;
        }
        .drag-area span{
            font-weight:500;
            color: #000;
        }
        .drag-area h3{
            font-weight:500;
        }
        .drag-area label{
            padding:5px 25px;
            border: 0;
            outline: none;
            background-color: #5256ad;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .file-container{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            border: solid 1px #ddd;
        }
        .status-text{
            padding: 0 10px;

        }
        .success{
            color: green;
        }
        .failure{
            color: #ff0000;
        }


    </style>

<script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
<link rel="stylesheet" href= "https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type = "text/css"/>

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>



<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt--4 pb-5">
        <!-- Table -->
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="card bg-secondary shadow border-0">
                    <div class="text-muted text-center mt-2 mb-4"><small><?php echo e(__('Complete your registration')); ?></small></div>
                    <div class="card-body px-lg-5 py-lg-5">
                        <center>
                            <a class="navbar-brand" href="<?php echo e(route('inicio')); ?>">
                                <img height="80px" width="80px" src="<?php echo e(asset('argon')); ?>/img/brand/blue.png" />
                            </a>
                        </center>

                        <?php if(Session::has('message')): ?>
                            <br><div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <br>
                        <?php if($user->email == NULL && $user->password == NULL): ?>
                            <form role="form" method="POST" action="<?php echo e(route('completedRegister')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                    </div>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" type="password" name="password" required>
                                    </div>
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                        </div>
                                        <input class="form-control" placeholder="<?php echo e(__('Confirm Password')); ?>" type="password" name="password_confirmation" required>
                                    </div>
                                </div>
                                <div class="text-muted font-italic">
                                    <small><?php echo e(__('password strength')); ?>: <span class="text-success font-weight-700"><?php echo e(__('strong')); ?>strong</span></small>
                                </div>
                                <div class="row my-4">
                                    <div class="col-12">
                                        <div class="custom-control custom-control-alternative custom-checkbox">
                                            <input class="custom-control-input" id="customCheckRegister" type="checkbox">
                                            <label class="custom-control-label" for="customCheckRegister">
                                                <span class="text-muted"><?php echo e(__('I agree with the')); ?> <a href="#!"><?php echo e(__('Privacy Policy')); ?></a></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Complete registration')); ?></button>
                                </div>
                            </form>
                        <?php elseif($user->name == null && $user->surname == null && $user->second_surname == null && $user->country == null && $user->gender == null): ?>
                            <form role="form" method="POST" action="<?php echo e(route('completedRegister')); ?>">
                                <?php echo csrf_field(); ?>
                                

                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Surname')); ?>" type="text" name="surname" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Second surname')); ?>" type="text" name="second_surname" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="input-group right">
                                    <select class="custom-select" id="inputGroupSelect04" name="country">
                                        <option selected disabled><?php echo app('translator')->get('Select state'); ?></option>
                                        <option value="Aguascalientes">Aguascalientes</option>
                                        <option value="Baja California">Baja California</option>
                                        <option value="Baja California Sur">Baja California Sur</option>
                                        <option value="Campeche">Campeche</option>
                                        <option value="Chiapas">Chiapas</option>
                                        <option value="Chihuahua">Chihuahua</option>
                                        <option value="CDMX">Ciudad de México</option>
                                        <option value="Coahuila">Coahuila</option>
                                        <option value="Colima">Colima</option>
                                        <option value="Durango">Durango</option>
                                        <option value="Estado de México">Estado de México</option>
                                        <option value="Guanajuato">Guanajuato</option>
                                        <option value="Guerrero">Guerrero</option>
                                        <option value="Hidalgo">Hidalgo</option>
                                        <option value="Jalisco">Jalisco</option>
                                        <option value="Michoacán">Michoacán</option>
                                        <option value="Morelos">Morelos</option>
                                        <option value="Nayarit">Nayarit</option>
                                        <option value="Nuevo León">Nuevo León</option>
                                        <option value="Oaxaca">Oaxaca</option>
                                        <option value="Puebla">Puebla</option>
                                        <option value="Querétaro">Querétaro</option>
                                        <option value="Quintana Roo">Quintana Roo</option>
                                        <option value="San Luis Potosí">San Luis Potosí</option>
                                        <option value="Sinaloa">Sinaloa</option>
                                        <option value="Sonora">Sonora</option>
                                        <option value="Tabasco">Tabasco</option>
                                        <option value="Tamaulipas">Tamaulipas</option>
                                        <option value="Tlaxcala">Tlaxcala</option>
                                        <option value="Veracruz">Veracruz</option>
                                        <option value="Yucatán">Yucatán</option>
                                        <option value="Zacatecas">Zacatecas</option>
                                    </select>
                                </div>
                                <br>
                
                                <div class="input-group right">
                                    <select class="custom-select" id="inputGroupSelect04" name="gender">
                                        <option selected><?php echo app('translator')->get('Choose gender'); ?></option>
                                        <option value="Men"><?php echo app('translator')->get('Men'); ?></option>
                                        <option value="Woman"><?php echo app('translator')->get('Woman'); ?></option>

                                    </select>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Complete registration')); ?></button>
                                </div>
                            </form>
                        <?php elseif($user->ine_front == null && $user->ine_back == null): ?>
                            <!-- forma pugaso--->
                            
                                <form role="form" method="POST" action="<?php echo e(route('ajaxIneBackUploadPost')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <?php echo app('translator')->get('INE image in front'); ?>
                                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>" id="userId">
                                        <div class="drag-area" id= "drag" name="drag">
                                            
                                            <h3 id="textG1" name = "textG1" class="tg"> Arrastre y suelte su archivo </h3>
                                            
                                        </div>
                                        <div id = "preview" name = "preview"></div>
                                </form>

                                <form role="form" method="POST" action="<?php echo e(route('ajaxIneBackUploadPost')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <?php echo app('translator')->get('INE image in back'); ?>
                                        
                                        <div class="drag-area" id= "drag2" name="drag2">
                                            <h3 id="textG2" name = "textG2"  class="tg"> Arrastre y suelte su archivo </h3>
                                            
                                        </div>
                                        <div id = "preview2" name = "preview2"></div>
                                </form>



                                <form role="form" method="POST" action="<?php echo e(route('ajaxIneBackUploadPost')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <?php echo app('translator')->get('Certificate image (Optional)'); ?>
                                        
                                        <div class="drag-area" id= "drag3" name="drag3">
                                            <h3 id="textG3" name = "textG3"  class="tg"> Arrastre y suelte su archivo </h3>
                                            
                                        </div>
                                        <div id = "preview3" name = "preview3"></div>
                                </form>
                                <center>
                                    <a href="<?php echo e(route('completeImagen', $user->id)); ?>" class="btn btn-primary mt-4">
                                        <?php echo e(__('Complete registration')); ?>

                                    </a>
                                </center>

                            <!--
                            <form role="form" method="POST" action="<?php echo e(route('completedRegister')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                

                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <?php echo app('translator')->get('INE image in front'); ?>
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('INE image in front')); ?>" type="file" name="ine_front" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <?php echo app('translator')->get('INE image in back'); ?>
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('INE image in back')); ?>" type="file" name="ine_back" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <?php echo app('translator')->get('Certificate image (Optional)'); ?>
                                    <div class="input-group input-group-alternative mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-name-83"></i></span>
                                        </div>
                                        <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Certificate image (Optional)')); ?>" type="file" name="certificate" value="<?php echo e(old('name')); ?>">
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                               
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Complete registration')); ?></button>
                                </div>
                            </form>
                            -->
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        button = document.querySelector(".button");

        userid = input = document.getElementById("userId").value;
        dropArea = document.getElementById("drag");
        dragText = document.getElementById("textG1");
        

        
        dropArea2 = document.getElementById("drag2");
        dragText2 = document.getElementById("textG2");
        
        
        
        
        let files;

        function uploadFile(file, id){
            formData = new FormData();
            formData.append("ine_front", file);
            formData.append("user_id", userid);
            formData.append("_token", $('input[name="_token"]').val());

            console.log("debe pasar aquiiiiiiiiiiiiiiiiiiiiii");
            console.log("formssaspppp ", file);
            console.log("despues ");

            try {
                $.ajax({
                        url: '/ajaxIneFrontUploadPost',
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,  
                        
                    }).done(function(res){
                        console.log("hecho si paso el post" )
                        document.getElementById(
                            `${id}st`
                        ).innerHTML= '<span class="succes">Archivo subido corectamente...</span>';
                    }).fail(function(error) {
                        console.log( error );
                    });
            } catch (error) {
                console.log($('input[name="_token"]').val());
                console.log(error);
            }
        }
        
        



        function processFile(file){
            
            docType = file[0].type
            console.log(docType)
            validExtension = ['image/jpeg', 'image/jpg', 'image/png']

            if(validExtension.includes(docType)){
                //archivo valido
                fileReader = new FileReader();
                id = `file-${Math.random().toString(32).substring(7)}`;

                fileReader.addEventListener('load', function(e){
                    fileUrl = fileReader.result;
                    image = `
                        <div id="${id}" class = "file-container">
                            <img src="${fileUrl}" alt="${file[0].name}" width= "50">
                            <div class="status">
                                
                                <span>${file[0].name}</span>
                                <span  id="${id}st" name = "${id}st" class="status-text"> Loading ...
                                </span>
                            </div>
                        </div>
                    `;
                    html = document.getElementById("preview").innerHTML;
                    document.getElementById("preview").innerHTML = image;
                });
                console.log("pocesandoooooo");
                fileReader.readAsDataURL(file[0]);
                uploadFile(file[0], id);
                
            }else{
                alert("No es un archivo valido");
            }
        }

        

        dropArea.addEventListener("dragover", function(e) {
            
            e.preventDefault();
            
            dropArea.classList.add("active");
            dragText.textContent = "Suelte para subir archivos";

        });

        dropArea.addEventListener("dragleave", function(e)  {
           
            e.preventDefault();
            
            dropArea.classList.remove("active");
            dragText.textContent = "Arrastre y suelte su archivo";
        });

        dropArea.addEventListener("drop", function(e)  {
            e.preventDefault();
           
            files = e.dataTransfer.files;
            console.log(files);
            processFile(files);
            dropArea.classList.remove("active");
            dragText.textContent = "Arrastre y suelte su archivo";
        });

        






        function uploadFile2(file, id){
            formData = new FormData();
            formData.append("ine_back", file);
            formData.append("user_id", userid);
            formData.append("_token", $('input[name="_token"]').val());

            console.log($('input[name="_token"]').val());
            console.log("formssaspppp ", file);
            console.log("despues ");

            try {
                $.ajax({
                        url: '/ajaxIneBackUploadPost',
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,  
                        
                    }).done(function(res){
                        console.log("hecho si paso el post" )
                        document.getElementById(
                            `${id}st`
                        ).innerHTML= '<span class="succes">Archivo subido corectamente...</span>';
                    }).fail(function(error) {
                        console.log( error );
                    });
            } catch (error) {
                console.log($('input[name="_token"]').val());
                console.log(error);
            }
        }
        
       



        function processFile2(file){
            
            docType = file[0].type
            console.log(docType)
            validExtension = ['image/jpeg', 'image/jpg', 'image/png']

            if(validExtension.includes(docType)){
                //archivo valido
                fileReader = new FileReader();
                id = `file-${Math.random().toString(32).substring(7)}`;

                fileReader.addEventListener('load', function(e){
                    fileUrl = fileReader.result;
                    image = `
                        <div id="${id}" class = "file-container">
                            <img src="${fileUrl}" alt="${file[0].name}" width= "50">
                            <div class="status">
                                
                                <span>${file[0].name}</span>
                                <span  id="${id}st" name = "${id}st" class="status-text"> Loading ...
                                </span>
                            </div>
                        </div>
                    `;
                    html = document.getElementById("preview2").innerHTML;
                    document.getElementById("preview2").innerHTML = image;
                });

                fileReader.readAsDataURL(file[0]);
                uploadFile2(file[0], id);
                
            }else{
                alert("No es un archivo valido");
            }
        }

        

        dropArea2.addEventListener("dragover", function(e) {
            
            e.preventDefault();
            
            dropArea2.classList.add("active");
            dragText2.textContent = "Suelte para subir archivos";

        });

        dropArea2.addEventListener("dragleave", function(e)  {
           
            e.preventDefault();
            
            dropArea2.classList.remove("active");
            dragText2.textContent = "Arrastre y suelte su archivo";
        });

        dropArea2.addEventListener("drop", function(e)  {
            e.preventDefault();
           
            files = e.dataTransfer.files;
            console.log(files);
            processFile2(files);
            dropArea2.classList.remove("active");
            dragText2.textContent = "Arrastre y suelte su archivo";
        });



        dropArea3 = document.getElementById("drag3");
        dragText3 = document.getElementById("textG3");
       


        function uploadFile3(file, id){
            formData = new FormData();
            formData.append("certificate", file);
            formData.append("user_id", userid);
            formData.append("_token", $('input[name="_token"]').val());

            console.log($('input[name="_token"]').val());
            console.log("formssaspppp ", file);
            console.log("despues ");

            try {
                $.ajax({
                        url: '/ajaxCertificateUploadPost',
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,  
                        
                    }).done(function(res){
                        console.log("hecho si paso el post" )
                        document.getElementById(
                            `${id}st`
                        ).innerHTML= '<span class="succes">Archivo subido corectamente...</span>';
                    }).fail(function(error) {
                        console.log( error );
                    });
            } catch (error) {
                console.log($('input[name="_token"]').val());
                console.log(error);
            }
        }
        
        



        function processFile3(file){
            
            docType = file[0].type
            console.log(docType)
            validExtension = ['image/jpeg', 'image/jpg', 'image/png']

            if(validExtension.includes(docType)){
                //archivo valido
                fileReader = new FileReader();
                id = `file-${Math.random().toString(32).substring(7)}`;

                fileReader.addEventListener('load', function(e){
                    fileUrl = fileReader.result;
                    image = `
                        <div id="${id}" class = "file-container">
                            <img src="${fileUrl}" alt="${file[0].name}" width= "50">
                            <div class="status">
                                
                                <span>${file[0].name}</span>
                                <span  id="${id}st" name = "${id}st" class="status-text"> Loading ...
                                </span>
                            </div>
                        </div>
                    `;
                    html = document.getElementById("preview").innerHTML;
                    document.getElementById("preview3").innerHTML = image;
                });

                fileReader.readAsDataURL(file[0]);
                uploadFile3(file[0], id);
                
            }else{
                alert("No es un archivo valido");
            }
        }

        

        dropArea3.addEventListener("dragover", function(e) {
            
            e.preventDefault();
            
            dropArea3.classList.add("active");
            dragText3.textContent = "Suelte para subir archivos";

        });

        dropArea3.addEventListener("dragleave", function(e)  {
           
            e.preventDefault();
            
            dropArea3.classList.remove("active");
            dragText3.textContent = "Arrastre y suelte su archivo";
        });

        dropArea3.addEventListener("drop", function(e)  {
            e.preventDefault();
           
            files = e.dataTransfer.files;
            console.log(files);
            processFile3(files);
            dropArea3.classList.remove("active");
            dragText3.textContent = "Arrastre y suelte su archivo";
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/auth/completedRegister.blade.php ENDPATH**/ ?>