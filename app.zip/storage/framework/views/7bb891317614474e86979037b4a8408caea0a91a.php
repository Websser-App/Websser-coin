

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Validate SMS Phone')); ?></h3>
            </div>
            <?php if(Session::has('message')): ?>
                <br>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo e(url('validationWithdrawals', ['id' => $withdrawals->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <center>
                        <div class="col-md-6">
                            <label for="code" class="form-label"><?php echo app('translator')->get('Code'); ?></label>
                            <input type="text" class="form-control" id="code" name="code" placeholder="<?php echo app('translator')->get('Code'); ?>" required>
                        </div>
                    </center>
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Continue')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/Tenantpayments/validate.blade.php ENDPATH**/ ?>