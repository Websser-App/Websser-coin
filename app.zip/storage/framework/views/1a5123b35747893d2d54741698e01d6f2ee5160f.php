<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <div class="navbar-brand pt-0">
            <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="<?php echo e(asset('argon')); ?>/img/theme/team-4-800x800.jpg">
            </span> <br>
            <div class="media-body ml-2 d-none d-lg-inline">
                <span class="mb-0 text-sm  font-weight-bold"><?php echo e(auth()->user()->name); ?></span> 
            </div>
        </div>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-9 collapse-close right">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(url('home')); ?>">
                        <i class="ni ni-chart-bar-32 text-black"></i> <?php echo e(__('Dashboard')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(url('building')); ?>">
                        <i class="ni ni-building text-black"></i> <?php echo e(__('Entity')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-examples">
                        <i class="ni ni-money-coins text-black" style="color: #f4645f;"></i>
                        <span class="nav-link-text text-black" style="color: #f4645f;"><?php echo e(__('Expenses')); ?></span>
                    </a>

                    <div class="collapse" id="navbar-examples">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('bills')); ?>">
                                    <?php echo e(__('Expenses')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('tenantpayments')); ?>">
                                    <?php echo e(__('Expense report')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('tenantpayments.wallet')); ?>">
                                    <?php echo e(__('Wallet')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link text-black" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </li>
            </ul>
            <!-- Divider -->
            <hr class="my-3">
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>