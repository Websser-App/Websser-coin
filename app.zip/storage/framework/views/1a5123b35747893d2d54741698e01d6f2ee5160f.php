<style>
    i{
        font-size: 30px;
    }
    .conf{
        font-size: 40px;
        position: ;
        top: 18%;
    }
    .avatar{
        width: 70%; 
        height: 70%;
    }
    @media  only screen and (max-width: 767px) {
        .conf{
            font-size: 20px;
            position: absolute;
            top: 10%;
            right: 22%;
        }
        .avatar{
        width: 20%; 
        height: 20%;
        margin-right: 80%;
        position: absolute;
        right:-75%;
        top: 40%;
        }
        
    }
</style>
<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <div class="navbar-brand pt-0">
            <div class = "mb-3"></div>
                <a title="Perfil" href="<?php echo e(url('profile')); ?>">
                    <i class="iconos ni ni-settings-gear-65 text-black conf " style=""></i>
                </a>
            <span class="avatar avatar-sm rounded-circle" style=" margin-right: 80%;">
                
                <div href="<?php echo e(url('profile')); ?>">
                    <img alt="Image placeholder"    src="<?php echo e(asset('argon')); ?>/img/theme/team-4-800x800.jpg" class= "">
                </div>
                
            </span> <br></br>
            <div class="media-body ml-2 d-none d-lg-inline">
                <span class="mb-0 text-sm  font-weight-bold" style=" font-size: 30px;"><?php echo e(auth()->user()->name); ?></span> 
            </div>
        </div>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-9 collapse-close right">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link text-black"  href="<?php echo e(url('home')); ?>">
                        <i class="iconos ni ni-chart-bar-32 text-blue " style="font-size: 30px;"></i> 
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(url('building')); ?>">
                        <i class="ni ni-building text-black" style="font-size: 30px; font-size: 30px;"></i> 
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Entity')); ?></span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(url('bills')); ?>">
                        <i class="ni ni-money-coins text-yellow" style="color: #f4645f; font-size: 30px;"></i>
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Expenses')); ?></span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(url('tenantpayments')); ?>">
                        <i class="bi bi-card-checklist text-black" style="color: #f4645f; font-size: 30px;"></i>
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Expense report')); ?></span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(route('tenantpayments.wallet')); ?>">
                        <i class="bi bi-cash text-green" style="color: #f4645f; font-size: 30px;"></i>
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Wallet')); ?></span>
                    </a>
                </li>

                
                <li class="nav-item">
                    <a class="nav-link text-black" href="<?php echo e(route('packages')); ?>">
                        <i class="bi bi-credit-card-2-front text-silver" style="color: #f4645f; font-size: 30px;"></i>
                        <span class="nav-link-text text-black" style="color: #f4645f; font-size: 110%;"><?php echo e(__('Subscription')); ?></span>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link text-black" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run" style="font-size: 30px; "></i>
                        <span font-size: 30px; style=" font-size: 110%;"><?php echo e(__('Logout')); ?></span>
                    </a>
                </li>
            </ul>
            <!-- Divider -->
            <hr class="my-3">
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>