<style>
     .contenerdor2{
        display: grid;
        gap: 1rem;
        grid-auto-rows: 30rem;
        grid-template-columns:repeat(auto-fill, minmax(35rem, 1fr));
        
        margin-top: 5%;
    }
    .btn2{
        width: 10%;
        margin-right: 15%;
        position: relative;
        right: -90%;
    }
    .imagenes{
        overflow: hidden;
        height: 100%;
    }
    .imagenP{
        width: 100%;
        height: 100%;
        background-image: url("<?php echo e(asset('argon')); ?>/img/v.png");
        background-repeat: no-repeat;
        background-size: 100% 100%;
    }
    @media  only screen and (max-width:524px) {
        .imagenes{
            overflow: hidden;
            height: 50%;
        }
    }
    @media  only screen and (max-width:345px) {
        .imagenes{
            overflow: hidden;
            height: 30%;
        }
    }
</style>



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Create Entity')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form  method="post" action="<?php echo e(route('building.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>                
                <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" name="user_id">
                <h2><?php echo app('translator')->get('Building Type'); ?> *</h2>
                <div align="right"> 
                    <h2><?php echo app('translator')->get('Building Location'); ?> *</h2>
                    <div class="d-grid gap-2">
                        <button title="<?php echo app('translator')->get('Address'); ?>" type="button" class="btn btn2 btn-primary" data-toggle="modal" data-target="#address">
                            <i class="ni ni-square-pin"></i>
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="address" tabindex="-1" role="dialog" aria-labelledby="address" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="address"><?php echo app('translator')->get('Address'); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <center>
                                            <h2><?php echo app('translator')->get('Building Location'); ?> *</h2>
                                        </center>
                                        <div class="form-group">
                                            <div class="row">
                                                <input type="text" name="address" class="form-control" placeholder="<?php echo app('translator')->get('Address'); ?>" id="input-address" readonly required/>
                                                <div class="col-6">
                                                    <input type="hidden" name="latitude" class="form-control" placeholder="<?php echo app('translator')->get('Latitude'); ?>" id="latitude" readonly required/>
                                                </div>
                                                <div class="col-6">    
                                                    <input type="hidden" name="longitude" class="form-control" placeholder="<?php echo e(__('Longitude')); ?>" id="longitude" readonly required/>
                                                </div>
                                            </div>
                                            
                                            <div id="webkulMap" style="height: 280px;" class="card"></div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>

                <center>
                <div class="container-lg">
                    <div class="contenerdor2">
                        <div  class="form-check form-check-inline<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                            <input type="checkbox" name="type_building" id="checkbox" class="form-check-input<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Vertical')); ?>"  value="vertical"  autofocus>
                            <label class="form-check-label" for="input-name"><?php echo e(__('Vertical')); ?></label>
                            <div class="imagenes">
                                <img src="<?php echo e(asset('argon')); ?>/img/v.png" height="100%" class="">
                            </div>
                            <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-check form-check-inline<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                            <input  type="checkbox" name="type_building" id="checkbox" class="form-check-input<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Horizontal')); ?>" value="horizontal"   autofocus>
                            <label class="form-check-label" for="input-name"><?php echo e(__('Horizontal')); ?></label>
                            <div class="imagenes">
                                <img src="<?php echo e(asset('argon')); ?>/img/h.png" height="100%" >
                            </div>
                            
                            <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div> 
                </div>
                </center>

                <h2><?php echo app('translator')->get('Building Information'); ?> *</h2>
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col">
                            <label for="rows" class="form-check-label"><?php echo e(__('Rows')); ?></label>
                            <input type="number" class="form-control" name="rows" id="rows" placeholder="<?php echo app('translator')->get('Rows'); ?>" required>
                        </div>
                        <div class="col">
                            <label for="columns" class="form-check-label"><?php echo e(__('Columns')); ?></label>
                            <input type="number" class="form-control" name="columns" id="columns" placeholder="<?php echo app('translator')->get('Columns'); ?>" required>
                        </div>
                    </div>
                </div> 
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
    <script type="text/javascript">
    $("input:checkbox").on('click', function() {
    var $box = $(this);
    if ($box.is(":checked")) {
        var group = "input:checkbox[name='" + $box.attr("name") + "']";
        $(group).prop("checked", false);
        $box.prop("checked", true);
    } else {
        $box.prop("checked", false);
    }
    });
</script>
<script type="text/javascript">
    var map;
    var marker;
    var myLatlng = new google.maps.LatLng(19.4326077, -99.13320799999997);
    var geocoder = new google.maps.Geocoder();
    var infowindow = new google.maps.InfoWindow();
    function initialize() {
        var mapOptions = {
        zoom: 10,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        
        map = new google.maps.Map(document.getElementById("webkulMap"), mapOptions);
        marker = new google.maps.Marker({
            map: map,
            position: myLatlng,
            draggable: true
        });

        google.maps.event.addListener(marker, 'dragend', function() {
            geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address_components = results[0].formatted_address;                        
                        $('#input-address').val(address_components);
                        $('#latitude').val(marker.getPosition().lat());
                        $('#longitude').val(marker.getPosition().lng());
                        infowindow.setContent(results[0].formatted_address);
                        infowindow.open(map, marker);
                    }
                }
            });
        });
    }
    google.maps.event.addDomListener(window, 'load', initialize);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/building/create.blade.php ENDPATH**/ ?>