

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Create Tenants')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="row g-3" method="POST" action="<?php echo e(route('tenants.update', $tenants->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="<?php echo e($tenants->building_id); ?>" name="building_id">
                <div class="col-md-6">
                  <label for="name" class="form-label"><?php echo app('translator')->get('Name'); ?></label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo app('translator')->get('Name'); ?>" value="<?php echo e($tenants->name); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="surname" class="form-label"><?php echo app('translator')->get('Surname'); ?></label>
                    <input type="text" class="form-control" id="surname" name="surname" placeholder="<?php echo app('translator')->get('Surname'); ?>" value="<?php echo e($tenants->surname); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="second_surname" class="form-label"><?php echo app('translator')->get('Second Surname'); ?></label>
                    <input type="text" class="form-control" id="second_surname" name="second_surname" placeholder="<?php echo app('translator')->get('Second surname'); ?>" value="<?php echo e($tenants->second_surname); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label"><?php echo app('translator')->get('Email'); ?></label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo app('translator')->get('Email'); ?>" value="<?php echo e($tenants->email); ?>" required>
                </div>
                <div class="col-md-4 center">
                    <label for="type" class="form-label"><?php echo app('translator')->get('Tenant type'); ?></label>
                    <select id="type" class="form-select" name="type" required>
                        <?php if($tenants->type == 'owner'): ?>
                            <option value="owner" selected readonly><?php echo app('translator')->get('Owner'); ?></option>
                            <option value="rent"><?php echo app('translator')->get('Rent'); ?></option>
                        <?php else: ?>
                            <option value="rent" selected readonly><?php echo app('translator')->get('Rent'); ?></option>
                            <option value="owner"><?php echo app('translator')->get('Owner'); ?></option>
                        <?php endif; ?>    
                    </select>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/tenants/edit.blade.php ENDPATH**/ ?>