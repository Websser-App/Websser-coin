

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Upload voucher')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo e(route('vouchers.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                    <label for="bills_id" class="form-label"><?php echo app('translator')->get('Expense concept'); ?></label>
                    <select class="form-select" aria-label="Default select example" name="bills_id">
                        <option selected disabled><?php echo app('translator')->get('Choose the concept of expense'); ?></option>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bill->id); ?>"><?php echo e($bill->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <div class="col-mb-4">
                        <label for="voucher" class="form-label"><?php echo app('translator')->get('Voucher'); ?></label>
                        <input class="form-control" type="file" id="voucher" name="voucher">
                    </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/bills/vouchers/create.blade.php ENDPATH**/ ?>