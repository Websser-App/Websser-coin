<!-- Top navbar -->
<nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
    <div class="container-fluid">
        <!-- Brand -->
        
        <!-- Form -->
        <!-- User -->
    </div>
</nav><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>