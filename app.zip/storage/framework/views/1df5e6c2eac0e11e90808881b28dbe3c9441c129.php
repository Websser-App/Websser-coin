

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .row{
        width: 99%;
        display: flex;
        grid-template-columns: repeat(3, auto);
        padding: 0 40px;
        gap: 0px;
        align-items: center;
    }
</style>
<div class="container-fluid mt-7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('List of expense payments')); ?></h3>
                            
                        </div>
                        <div class="card-footer py-4">
                            <nav class="d-flex justify-content-end" aria-label="...">
                            <h3 style="width: 98%; text-align: right; font-family: Arial, Helvetica, sans-serif; margin:0; padding:0;">Total a pagar: $<?php echo e(getAmount((($bills->amount * $tenantsCount)-$tenantsSum), 2)); ?></h4>
                                
                            </nav>
                        </div>
                    </div>
                </div>
                
                <div class="col-12">
                                        </div>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table id="tablelistTenantsPayments" class="table align-items-center table-flush">

                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Departament'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Tenant name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Expense name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('IsActive'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Actions'); ?></th>


                            </tr>
                        </thead>
                        <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tenant->departaments->number_departament); ?></td>
                                <td><?php echo e($tenant->name); ?> <?php echo e($tenant->surname); ?> <?php echo e($tenant->second_surname); ?></td>
                                <td><?php echo e($bills->name); ?></td>
                                <?php if($tenant->amount): ?>
                                    <td>$<?php echo e(getAmount($tenant->amount,2)); ?></td>
                                    <td class="bg-success"><?php echo app('translator')->get('Paid'); ?></td>
                                    <td>
                                        <button title="<?php echo app('translator')->get('Not payed'); ?>" class="btn btn-sm text-danger"  data-bs-toggle="modal"  data-bs-target="#notPayedModal<?php echo e($tenant->payments_id); ?>" data-id="<?php echo e($tenant->payments_id); ?>">
                                            <i style="font-size: 20px" class="ni ni-fat-remove"></i>
                                        </button>
                                    </td>
                                    <!-- Modal -->
                                    <div class="modal fade" id="notPayedModal<?php echo e($tenant->payments_id); ?>" tabindex="-1" role="dialog" aria-labelledby="notPayedModal<?php echo e($tenant->payments_id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Address'); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <center>
                                                    <form action="<?php echo e(route('bills.notPayed', $tenant->payments_id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="col-md-6">
                                                            <label for="amount" class="form-label text-center"><?php echo app('translator')->get('Amount'); ?></label>
                                                            <input type="text" class="form-control text-center" id="amount" name="amount" value="0" placeholder="<?php echo app('translator')->get('Amount'); ?>" readonly required>
                                                        </div>
                                                        <div class="text-center">
                                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </form>
                                                </center>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                                            </div>
                                        </div>
                                        </div>
                                    </div> 
                                <?php elseif(!$tenant->amount || $tenant->amount == 0): ?>
                                    <td>$0</td>
                                    <td class="bg-danger"><?php echo app('translator')->get('Not payed'); ?></td>
                                    <td>
                                        <button title="<?php echo app('translator')->get('Paid'); ?>" class="btn btn-sm text-success" data-bs-toggle="modal"  data-bs-target="#successModal<?php echo e($tenant->departaments->id); ?>" data-id="<?php echo e($tenant->departaments->id); ?>">
                                            <i style="font-size: 20px" class="ni ni-check-bold"></i>
                                        </button>
                                    </td>
                                    <!-- Modal -->
                                    <div class="modal fade" id="successModal<?php echo e($tenant->departaments->id); ?>" tabindex="-1" role="dialog" aria-labelledby="successModal<?php echo e($tenant->departaments->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Address'); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <center>
                                                    <form action="<?php echo e(route('bills.paid', $tenant->departaments->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="payments_id" value="<?php echo e($tenant->payments_id); ?>">
                                                        <input type="hidden" name="bills_id" value="<?php echo e($bills->id); ?>">
                                                        <div class="col-md-6">
                                                            <label for="amount" class="form-label text-center"><?php echo app('translator')->get('Amount'); ?></label>
                                                            <input type="text" class="form-control text-center" id="amount" name="amount" value="<?php echo e($bills->amount); ?>" placeholder="<?php echo app('translator')->get('Amount'); ?>" required readonly>
                                                        </div>
                                                        <div class="text-center">
                                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </form>
                                                </center>
                                            </div>
                                            <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                                            </div>
                                        </div>
                                        </div>
                                    </div> 
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/bills/tenants.blade.php ENDPATH**/ ?>