<style>
    .precios{
        border-radius: 20px;
        font-size: 100%;
        text-align: center;
        
        background-color: white;
        border-radius: 25px;
    }
    .contenerdor2{
        justify-content: center;
        margin-bottom: 10%;
        display: grid;
        gap: 1rem;
        grid-auto-rows: 25rem;
        grid-template-columns:repeat(auto-fill, minmax(min(100%, 15rem),15rem));
        margin-left: 5%;
        margin-right: 5%;
        
        
    }
    .titulo{
        margin-left:5%;
        font-size: 150%;
        font-weight: bold;
    }
    i{
        font-size: 120%;
    }
    .conttenedorImg{
        overflow: hidden;
        height: 20%;
        max-height: 40%;
    }
</style>





<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt-7">
    
    <div class="row">
        <div class="col">
            <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

            <h3 class="titulo"><?php echo e(__('Departaments')); ?></h3>
            <div class= "contenerdor2">
                
                    <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <div class="precios">
                            <?php if($departament->tenants == NULL): ?>
                                
                                    <div class="dropdown">
                                        <a class="btn btn-sm btn-icon-only text-primary btnI" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            
                                            <button title="<?php echo app('translator')->get('Edit'); ?>" class="dropdown-item"  data-bs-toggle="modal"  data-bs-target="#edit<?php echo e($departament->id); ?>" data-id="<?php echo e($departament->id); ?>"><?php echo app('translator')->get('Edit'); ?></button>

                                            <form action="<?php echo e(route('departaments.destroy', $departament->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="submit" class="dropdown-item" value="<?php echo e(__('Delete')); ?>">
                                            </form>
                                        </div>
                                    </div>

                                    <div class="row" height="50%">
                                        <div class="conttenedorImg">
                                            <img src="<?php echo e(asset('argon')); ?>/img/theme/departament.jpg" width="100%" class="">
                                        </div>
                                    </div>
                                    <a href="<?php echo e(route('tenants.create', $departament->id)); ?>" class="row">
                                    <!--<h5 class="card-title"><?php echo app('translator')->get('Information'); ?></h5>--->
                                        <strong><b> <?php echo app('translator')->get(''); ?>ID:</b></strong>
                                        <p class="card-text"><?php echo e($departament->UUID); ?></p>
                                        <strong><b> <?php echo app('translator')->get(''); ?>N° Departamento:</b></strong>
                                        <p class="card-text"><?php echo e($departament->number_departament); ?></p>
                                        <strong><b> <?php echo app('translator')->get(''); ?>Inquilino:</b></strong>
                                        <?php if($departament->tenants != NULL): ?>
                                            <p class="card-text"><?php echo e($departament->tenants->name); ?> <?php echo e($departament->tenants->surname); ?> <?php echo e($departament->tenants->second_surname); ?></p>
                                        <?php else: ?>
                                            <p class="card-text"><?php echo app('translator')->get('Not assigned'); ?></p>
                                        <?php endif; ?>
                                    </a>
                                
                            <?php else: ?>
                                <div class="dropdown">
                                    <a class="btn btn-sm btn-icon-only text-primary btnI" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                        
                                        <button title="<?php echo app('translator')->get('Edit'); ?>" class="dropdown-item"  data-bs-toggle="modal"  data-bs-target="#edit<?php echo e($departament->id); ?>" data-id="<?php echo e($departament->id); ?>"><?php echo app('translator')->get('Edit'); ?></button>
                                        <form action="<?php echo e(route('departaments.destroy', $departament->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" class="dropdown-item" value="<?php echo e(__('Delete')); ?>">
                                        </form>
                                    </div>
                                </div>
                                    
                                <div class="row" height="50%">
                                    <div class="conttenedorImg">
                                        <img src="<?php echo e(asset('argon')); ?>/img/theme/departament.jpg" width="100%" class="">
                                    </div>
                                </div>
                                <a href="<?php echo e(route('tenants.edit', $departament->tenants->id)); ?>" class="row">
                                <!--<h5 class="card-title"><?php echo app('translator')->get('Information'); ?></h5>--->
                                    <strong><b> <?php echo app('translator')->get(''); ?>ID:</b></strong>
                                    <p class="card-text"><?php echo e($departament->UUID); ?></p>
                                    <strong><b> <?php echo app('translator')->get(''); ?>N° Departamento:</b></strong>
                                    <p class="card-text"><?php echo e($departament->number_departament); ?></p>
                                    <strong><b> <?php echo app('translator')->get(''); ?>Inquilino:</b></strong>
                                    <?php if($departament->tenants != NULL): ?>
                                        <p class="card-text"><?php echo e($departament->tenants->name); ?> <?php echo e($departament->tenants->surname); ?> <?php echo e($departament->tenants->second_surname); ?></p>
                                    <?php else: ?>
                                        <p class="card-text"><?php echo app('translator')->get('Not assigned'); ?></p>
                                    <?php endif; ?>
                                </a>
                                
                            <?php endif; ?>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="edit<?php echo e($departament->id); ?>" tabindex="-1" role="dialog" aria-labelledby="edit<?php echo e($departament->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Address'); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <center>
                                        <form action="<?php echo e(route('departaments.update', $departament->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="col-md-6">
                                                <label for="number_departament" class="form-label text-center"><?php echo app('translator')->get('Departament Number'); ?></label>
                                                <input type="text" class="form-control text-center" id="number_departament" name="number_departament" value="<?php echo e($departament->number_departament); ?>" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" required>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                            </div>
                                        </form>
                                    </center>
                                </div>
                                <div class="modal-footer">
                                    
                                </div>
                            </div>
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

            </div>

            <!--
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class=""></h3>
                        </div>
                    </div>
                </div>
                
                <div class="col-12">
                </div>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <h3 class="titulo"><?php echo e(__('Departaments')); ?></h3>
                <div class= "contenerdor2">
                    
                        <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            <div class="precios">
                                <?php if($departament->tenants == NULL): ?>
                                    
                                        <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.create', $departament->id)); ?>" class="btn btn-sm text-primary">
                                            <i class="ni ni-single-02" style="font-size: 120%;"></i>
                                        </a>
                                    
                                <?php else: ?>
                                    
                                        <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.edit', $departament->tenants->id)); ?>" class="btn btn-sm text-primary">
                                            <i class="ni ni-settings" style="font-size: 120%;"></i>
                                        </a>
                                    
                                <?php endif; ?>
                                <h5 class="card-title"><?php echo app('translator')->get('Information'); ?></h5>
                                <strong><b> <?php echo app('translator')->get('ID Bulding'); ?>:</b></strong>
                                <p class="card-text"><?php echo e($departament->buildings->UUID); ?></p>
                                <strong><b> <?php echo app('translator')->get('Departament Number'); ?>:</b></strong>
                                <p class="card-text"><?php echo e($departament->UUID); ?></p>
                                <strong><b> <?php echo app('translator')->get('Tenant name'); ?>:</b></strong>
                                <?php if($departament->tenants != NULL): ?>
                                <p class="card-text"><?php echo e($departament->tenants->name); ?> <?php echo e($departament->tenants->surname); ?> <?php echo e($departament->tenants->second_surname); ?></p>
                                <?php else: ?>
                                    <p class="card-text"><?php echo app('translator')->get('Not assigned'); ?></p>
                                <?php endif; ?>
                                <p class="card-text"><?php echo e($departament->number_departament); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

                </div>

                <div class="table-responsive" >
                    <table class="table align-items-center table-flush" id="tablelist">

                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('ID Bulding'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('ID departament'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Departament Number'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Tenant name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Actions'); ?></th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                    <td><?php echo e($departament->buildings->UUID); ?></td>
                                    <td><?php echo e($departament->UUID); ?></td>
                                    <td><?php echo e($departament->number_departament); ?></td>
                                    <?php if($departament->tenants != NULL): ?>
                                        <td><?php echo e($departament->tenants->name); ?> <?php echo e($departament->tenants->surname); ?> <?php echo e($departament->tenants->second_surname); ?></td>
                                    <?php else: ?>
                                        <td><?php echo app('translator')->get('Not assigned'); ?></td>
                                    <?php endif; ?>
                                    <?php if($departament->tenants == NULL): ?>
                                        <td class="text-right">
                                            <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.create', $departament->id)); ?>" class="btn btn-sm text-primary">
                                                <i class="ni ni-single-02"></i>
                                            </a>
                                        </td>
                                    <?php else: ?>
                                        <td class="text-right">
                                            <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.edit', $departament->tenants->id)); ?>" class="btn btn-sm text-primary">
                                                <i class="ni ni-settings"></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        
                    </nav>
                </div>
            </div>
            -->
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/departaments/index.blade.php ENDPATH**/ ?>