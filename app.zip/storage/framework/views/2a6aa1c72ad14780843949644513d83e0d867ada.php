<style>
    .precios{
        font-size: 100%;
        text-align: center;
        
        background-color: white;
        border-radius: 25px;
    }
    .contenerdor2{
        justify-content: center;
        margin-bottom: 10%;
        display: grid;
        gap: 1rem;
        grid-auto-rows: 13rem;
        grid-template-columns:repeat(auto-fit, minmax(15rem, 1fr));
        margin-left: 5%;
        margin-right: 5%;
        
    }
</style>





<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt-7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Departaments')); ?></h3>
                        </div>
                    </div>
                </div>
                
                <div class="col-12">
                </div>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive" >
                    <table class="table align-items-center table-flush" id="tablelist">

                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('ID Bulding'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('ID departament'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Departament Number'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Tenant name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Actions'); ?></th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td><?php echo e($departament->buildings->UUID); ?></td>
                            <td><?php echo e($departament->UUID); ?></td>
                            <td><?php echo e($departament->number_departament); ?></td>
                            <?php if($departament->tenants != NULL): ?>
                                <td><?php echo e($departament->tenants->name); ?> <?php echo e($departament->tenants->surname); ?> <?php echo e($departament->tenants->second_surname); ?></td>
                            <?php else: ?>
                                <td><?php echo app('translator')->get('Not assigned'); ?></td>
                            <?php endif; ?>
                            <?php if($departament->tenants == NULL): ?>
                                <td class="text-right">
                                    <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.create', $departament->id)); ?>" class="btn btn-sm text-primary">
                                        <i class="ni ni-single-02"></i>
                                    </a>
                                </td>
                            <?php else: ?>
                                <td class="text-right">
                                    <a title="<?php echo app('translator')->get('Tenants'); ?>" href="<?php echo e(route('tenants.edit', $departament->tenants->id)); ?>" class="btn btn-sm text-primary">
                                        <i class="ni ni-settings"></i>
                                    </a>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/departaments/index.blade.php ENDPATH**/ ?>