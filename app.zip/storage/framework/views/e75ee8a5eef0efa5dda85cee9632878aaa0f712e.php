<!DOCTYPE html>
<html lang="en" style="margin: 30px 10px">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Reporte de gastos</title>
</head>
<body >
    <div style="width: 100%; height: 97%; background-color: #FFFFFF; border-radius: 5px; border: 1px solid #000000;">
        <h1 style="background-color: #000000; width: 97.5%; height: auto; color: #FFFFFF; text-align: center; font-family: Arial; padding: 16px; border-top-left-radius: 5px; border-top-right-radius: 5px; margin-top: 0px;">Pago de gastos</h1>
            <div class="table-responsive" style="margin-top: -25px">
                <table style="width: 100%; text-align: center; font-family: Arial, Helvetica, sans-serif; padding: 0 5px; margin-top: 0">
                    <thead  style="border-bottom: 1px solid #000000">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Departament'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Tenant name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Expense name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('IsActive'); ?></th>


                            </tr>
                        </thead>
                        <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tenant->departaments->number_departament); ?></td>
                                <td><?php echo e($tenant->name); ?> <?php echo e($tenant->surname); ?> <?php echo e($tenant->second_surname); ?></td>
                                <td><?php echo e($bills->name); ?></td>
                                <?php if($tenant->amount): ?>
                                    <td>$<?php echo e(getAmount($tenant->amount,2)); ?></td>
                                    <td class="bg-success"><?php echo app('translator')->get('Paid'); ?></td>
                                <?php elseif(!$tenant->amount || $tenant->amount == 0): ?>
                                    <td>$0</td>
                                    <td class="bg-danger"><?php echo app('translator')->get('Not payed'); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div style="border-bottom: 1px solid #000000"></div>
                <div style="text-align: right; width: auto; height: auto; border: 3px solid black; margin: 0;">
                    <h3 style="width: 98%; text-align: right; font-family: Arial, Helvetica, sans-serif; margin:0; padding:0;">Total</h4>
                    <h5 style="width: 100%; text-align: right; font-family: Arial, Helvetica, sans-serif; margin:0; padding:0;">$<?php echo e(getAmount($sumAmounts, 2)); ?></h5>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    <?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/TenantPayments/pdf/reportAllPDF.blade.php ENDPATH**/ ?>