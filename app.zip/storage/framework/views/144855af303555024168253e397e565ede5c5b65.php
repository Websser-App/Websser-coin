<style>
    .precios{
        font-size: 100%;
        text-align: center;
        
        background-color: white;
        border-radius: 25px;
    }
    .contenerdor2{
        justify-content: center;
        margin-bottom: 10%;
        display: grid;
        gap: 1rem;
        grid-auto-rows: 13rem;
        grid-template-columns:repeat(auto-fit, minmax(15rem, 1fr));
        margin-left: 5%;
        margin-right: 5%;
        
    }
    .marginado{
        margin-top: 3%;
        
    }
</style>




<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Assign departments')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="contenerdor2" method="post" action="<?php echo e(route('departaments.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" name="user_id">
                <input type="hidden" class="form-control" id="building_id" name="building_id" value="<?php echo e($buildings->id); ?>">


                <?php if($departaments->isEmpty()): ?>

                    <?php for($i = 0; $i < $inputsDepartaments; $i++): ?>
                        <div class="precios">
                            <div class="container">
                                <label for="number_departament" class="form-label"><?php echo app('translator')->get('Assign department'); ?></label>
                                <select  class="form-select marginado" aria-label="Default select example" name="buildings_row[]">
                                    <option selected disabled><?php echo app('translator')->get('Choose the floor number'); ?></option>
                                    <?php for($j = 1; $j <= $buildings->rows; $j++): ?>
                                        <option value="<?php echo e($j); ?>"><?php echo e($j); ?></option>
                                    <?php endfor; ?>
                                </select><br>
                                <input type="text" class="form-control marginado" id="number_departament" name="number_departament[]"  placeholder="<?php echo app('translator')->get('Departament Number'); ?>"  required>
                            </div>
                        </div>
                    <?php endfor; ?>
                    

                <?php else: ?>


                    <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($departament->number_departament != NULL ): ?>
                            <div class="precios">
                                <div class="container">
                                    <label for="number_departament" class="form-label"><?php echo app('translator')->get('Departament Number'); ?> </label>
                                    <select class="form-select" aria-label="Default select example" name="buildings_row[]">
                                        <option selected disabled><?php echo app('translator')->get('Choose the floor number'); ?></option>
                                        <?php for($j = 1; $j <= $buildings->rows; $j++): ?>
                                            <option value="<?php echo e($j); ?>"><?php echo e($j); ?></option>
                                        <?php endfor; ?>
                                    </select><br>
                                    <input type="text" class="form-control" id="number_departament" name="number_departament[]" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" value="<?php echo e($departament->number_departament); ?>" required disabled>
                                </div>
                            </div>
                        <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php for($i = $index+1; $i < $inputsDepartaments; $i++): ?>
                        <?php if($index !=  $inputsDepartaments): ?>
                        <div class="precios">
                            <div class="container">
                                <label for="number_departament" class="form-label"><?php echo app('translator')->get('Departament Number'); ?></label>
                                <select class="form-select" aria-label="Default select example" name="buildings_row[]">
                                    <option selected disabled><?php echo app('translator')->get('Choose the floor number'); ?></option>
                                    <?php for($j = 1; $j <= $buildings->rows; $j++): ?>
                                        <option value="<?php echo e($j); ?>"><?php echo e($j); ?></option>
                                    <?php endfor; ?>
                                </select><br>
                                <input type="text" class="form-control" id="number_departament" name="number_departament[]" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" required>
                            </div>
                            </div>
                        <?php endif; ?>
                    <?php endfor; ?>


                <?php endif; ?>


                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/departaments/create.blade.php ENDPATH**/ ?>