

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Assign departments')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo e(route('departaments.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" class="form-control" id="building_id" name="building_id" value="<?php echo e($buildings->id); ?>">


                <?php if($departaments->isEmpty()): ?>
                    <?php for($i = 0; $i < $inputsDepartaments; $i++): ?>
                        <div class="col-md-4">
                            <label for="number_departament" class="form-label"><?php echo app('translator')->get('Departament Number'); ?></label>
                            <input type="text" class="form-control" id="number_departament" name="number_departament[]" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" required>
                        </div>
                    <?php endfor; ?>
                <?php else: ?>
                    <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($departament->number_departament != NULL ): ?>
                            <div class="col-md-4">
                                <label for="number_departament" class="form-label"><?php echo app('translator')->get('Departament Number'); ?></label>
                                <input type="text" class="form-control" id="number_departament" name="number_departament[]" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" value="<?php echo e($departament->number_departament); ?>" required disabled>
                            </div>
                        <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php for($i = $index+1; $i < $inputsDepartaments; $i++): ?>
                        <?php if($index !=  $inputsDepartaments): ?>
                            <div class="col-md-4">
                                <label for="number_departament" class="form-label"><?php echo app('translator')->get('Departament Number'); ?></label>
                                <input type="text" class="form-control" id="number_departament" name="number_departament[]" placeholder="<?php echo app('translator')->get('Departament Number'); ?>" required>
                            </div>
                        <?php endif; ?>
                    <?php endfor; ?>
                <?php endif; ?>


                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/departaments/create.blade.php ENDPATH**/ ?>