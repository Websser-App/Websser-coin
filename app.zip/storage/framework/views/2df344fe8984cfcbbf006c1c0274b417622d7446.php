<!DOCTYPE html>
<html>
<head>
    <title>Reporte de pago</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($body); ?></p>
     
    <p><?php echo e($tenantpayments->tenants->name); ?></p>
</body>
</html><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/TenantPayments/pdf/PaymentReportEmail.blade.php ENDPATH**/ ?>