

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Create expense concept')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo e(route('tenantpayments.storeDepartament')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                    <div class="input-group right">
                        <select class="custom-select" id="inputGroupSelect04" name="departament_id">
                            <option selected><?php echo app('translator')->get('Choose the departament'); ?></option>
                                <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($departament->id); ?>"><?php echo e($departament->UUID); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                        </select>
                    </div>
                    <div class="input-group right">
                        <select class="custom-select" id="inputGroupSelect04" name="bill_id">
                            <option selected><?php echo app('translator')->get('Choose the bills'); ?></option>
                                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bill->id); ?>"><?php echo e($bill->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="amount" class="form-label"><?php echo app('translator')->get('Amount'); ?></label>
                        <input type="text" class="form-control" id="amount" name="amount" placeholder="<?php echo app('translator')->get('Amount'); ?>" required>
                    </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Continue')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/TenantPayments/completePayment.blade.php ENDPATH**/ ?>