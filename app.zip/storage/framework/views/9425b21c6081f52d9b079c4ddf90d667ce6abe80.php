<div class="header bg-gradient-primary py-4 py-lg-4">
    <div class="container">
        <div class="header-body text-center mb-4">
            <div class="row justify-content-center">
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/layouts/headers/page.blade.php ENDPATH**/ ?>