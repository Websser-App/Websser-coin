

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt-7">
    <div class="row">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0"><?php echo e(__('Vouchers')); ?></h3>
                </div>
                <div class="col-4 text-right">
                    <a href="<?php echo e(route('vouchers.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Upload vouchers')); ?></a>
                </div>
            </div>
            <div class="col-12 text-center">
                <a href="<?php echo e(url('bills')); ?>" class="btn btn-secondary" ><?php echo app('translator')->get('Expense Concepts'); ?></a>
                <button href="<?php echo e(url('vouchers')); ?>" class="btn btn-secondary active" disabled><?php echo app('translator')->get('Vouchers'); ?></button>
            </div>
        </div>
                
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-4">
        <div class="card">
            <img src="data:image/png;base64,<?php echo e($voucher->voucher); ?>" width="auto" height=auto alt="">
          <div class="card-body">
            <h5 class="card-title"><?php echo app('translator')->get('Information'); ?></h5>
            <strong><b> <?php echo app('translator')->get('Payment name'); ?>:</b></strong>
            <p class="card-text"><?php echo e($voucher->bills->name); ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/bills/vouchers/index.blade.php ENDPATH**/ ?>