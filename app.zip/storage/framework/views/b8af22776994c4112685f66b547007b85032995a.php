

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body onload="initialize();">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <h3 class="mb-0"><?php echo e(__('Create Tenants')); ?></h3>
            </div>
        </div>
        <div class="card-body">
            <form class="row g-3" method="post" action="<?php echo e(route('tenants.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="departament_id" value="<?php echo e($departament->id); ?>">
                <input type="hidden" name="building_id" value="<?php echo e($departament->building_id); ?>">

                <div class="col-md-6">
                  <label for="name" class="form-label"><?php echo app('translator')->get('Name'); ?></label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo app('translator')->get('Name'); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="surname" class="form-label"><?php echo app('translator')->get('Surname'); ?></label>
                    <input type="text" class="form-control" id="surname" name="surname" placeholder="<?php echo app('translator')->get('Surname'); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="second_surname" class="form-label"><?php echo app('translator')->get('Second surname'); ?></label>
                    <input type="text" class="form-control" id="second_surname" name="second_surname" placeholder="<?php echo app('translator')->get('Second surname'); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label"><?php echo app('translator')->get('Email'); ?></label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo app('translator')->get('Email'); ?>" required>
                </div>
                <div class="col-md-4 center">
                    <label for="type" class="form-label"><?php echo app('translator')->get('Tenant type'); ?></label>
                    <select id="type" class="form-select" name="type" required>
                      <option disabled selected><?php echo app('translator')->get('Tenant type'); ?></option>
                      <option value="owner"><?php echo app('translator')->get('Owner'); ?></option>
                      <option value="rent"><?php echo app('translator')->get('Rent'); ?></option>
                    </select>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/tenants/create.blade.php ENDPATH**/ ?>