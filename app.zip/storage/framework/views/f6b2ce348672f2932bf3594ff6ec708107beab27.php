<!DOCTYPE html>
<html>
<head>
    <title>Reporte de pago</title>
</head>
<body>
    <h1>Reporte de pago</h1>
    <p>Demo de pago</p>
     
    <p><?php echo e($tenantpayments->tenants->name); ?></p>
</body>
</html><?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\BuildingWebser\resources\views/TenantPayments/pdf/PaymentReport.blade.php ENDPATH**/ ?>