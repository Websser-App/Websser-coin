<!DOCTYPE html>
<html>
<head>
    <title>Reporte de pago</title>
</head>
<body>
    <h1>Reporte de pago</h1>
    <p>Demo de pago</p>
     
    <p>{{$tenantpayments->tenants->name}}</p>
</body>
</html>