<!DOCTYPE html>
<html>
<head>
    <title>Reporte de pago</title>
</head>
<body>
    <h1>{{ $title }}</h1>
    <p>{{ $body }}</p>
     
    <p>{{$tenantpayments->tenants->name}}</p>
</body>
</html>