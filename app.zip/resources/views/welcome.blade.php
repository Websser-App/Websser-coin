@extends('layouts.app', ['class' => 'bg-default'])

@section('content')
    <div class="container mt--10 pb-5"></div>
@endsection
