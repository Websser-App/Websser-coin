<div class="header bg-gradient-primary py-4 py-lg-4">
    <div class="container">
        <div class="header-body text-center mb-4">
            <div class="row justify-content-center">
            </div>
        </div>
    </div>
</div>